package com.onlinegrocerydeliverysystem.serviceimpl;

import java.nio.charset.StandardCharsets;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import com.google.common.hash.Hashing;
import com.onlinegrocerydeliverysystem.dto.UserDto;
import com.onlinegrocerydeliverysystem.exceptions.InvalidLoginCredentialsException;
import com.onlinegrocerydeliverysystem.exceptions.PasswordNotValidException;
import com.onlinegrocerydeliverysystem.exceptions.UserAlreadyRegisteredException;
import com.onlinegrocerydeliverysystem.exceptions.UserNotFoundException;
import com.onlinegrocerydeliverysystem.exceptions.UserNotLoggedInException;
import com.onlinegrocerydeliverysystem.models.User;
import com.onlinegrocerydeliverysystem.models.UserLogin;
import com.onlinegrocerydeliverysystem.repository.IUserRepository;
import com.onlinegrocerydeliverysystem.service.UserService;
import com.onlinegrocerydeliverysystem.validation.PasswordValidation;

/**
 *  This is the User Service  Implementation class
 */
@Service
public class UserServiceImpl implements UserService {

	static Logger log = Logger.getLogger(UserServiceImpl.class.getName());
	
	@Autowired
	private IUserRepository userRepository;
	
	
	User currentUser = null;
	
	/**
	 * This method is to add the User to the database & it returns User object
	 * @param Users object
	 * @throws UserAlreadyRegisteredException
	 * @throws PasswordNotValidException
	 * @return  User Object
	 */
	@Override
	public User addUser(User user) throws UserAlreadyRegisteredException, PasswordNotValidException{
		if(userRepository.existsByEmail(user.getEmailId()))
		{
			log.error("User is already registered with email id : "+user.getEmailId());
			throw new UserAlreadyRegisteredException("User already registered with email id :"+user.getEmailId());
		}
		
		if(PasswordValidation.passwordValid(user.getPassword()))
			user.setPassword(Hashing.sha256().hashString(user.getPassword(),StandardCharsets.UTF_8).toString());
		else 
		{
			log.error("Password should have atleast 8 characters, atleast 1 uppercase, atleast 1 lowercase, atleast 1 number & atleast 1 special character.");
			throw new PasswordNotValidException("Password should have atleast 8 characters, atleast 1 uppercase, atleast 1 lowercase, atleast 1 number & atleast 1 special character.");
		}
		
		userRepository.save(user);
		log.info("User is added successfully");
		return user;
	}
	
	/**
	 * This method is to delete the user details from database & it returns string message
	 * @param Users id
	 * @throws UserNotFoundException
	 * @throws UserNotLoggedInException
	 * @return String message
	 */
	@Override
	public ResponseEntity<String> deleteUser(String emailId) throws UserNotFoundException, UserNotLoggedInException{
		if(userRepository.existsByEmail(emailId))
		{
			if(currentUser!=null)
			{
				User user = userRepository.findByEmail(emailId);
				userRepository.delete(user);
				currentUser=null;
				log.info("User has been deleted successfully");
				return new ResponseEntity<>("User deleted successfully",HttpStatus.OK);
			}
			else
			{
				log.error("User has not logged in");
				throw new UserNotLoggedInException("User has not logged in");
			}
		}
		log.error("User not found with the email id : "+emailId);
		throw new UserNotFoundException("User not found with email id :"+emailId);
	}

	/**
	 * This method is to update the user details from database & it returns updated user object
	 * @param Users object
	 * @param Email id of User
	 * @throws UserNotFoundException
	 * @throws UserNotLoggedInException
	 * @return Updated User object
	 */
	@Override
	public User updateUser(User user,String emailId) throws UserNotFoundException, UserNotLoggedInException{
		if(userRepository.existsByEmail(emailId))
		{
			if(currentUser!=null)
			{User existingUser = userRepository.findByEmail(emailId);
			existingUser.setEmailId(user.getEmailId());
			String encryptedPassword = Hashing.sha256().hashString(user.getPassword(),StandardCharsets.UTF_8).toString();
	        existingUser.setPassword(encryptedPassword);
		 	existingUser.setFirstName(user.getFirstName());
			existingUser.setLastName(user.getLastName());
			existingUser.setPhoneNumber(user.getPhoneNumber());
			userRepository.save(existingUser);
			log.info("User has been updated successfully");
			return existingUser;
			}
			else
			{
				log.error("User has not looged in");
				throw new UserNotLoggedInException("User not logged in");
			}
		}
		log.error("User not found with email id : "+emailId);
		throw new UserNotFoundException("User not found with email id : "+emailId);
		
	}
	
	/**
	 * This method is to login the user in the system
	 * It throws UserNotFoundException & InvalidLoginCredentialsException
	 * @param emailId of user
	 * @param password of user
	 * @throws UserNotFoundException
	 * @throws InvalidLoginCredentialsException
	 * @return Http Response & string message
	 */
	@Override
	public ResponseEntity<Object> loginUser(UserLogin userLogin)throws UserNotFoundException, InvalidLoginCredentialsException {
		String encryptedPassword = Hashing.sha256().hashString(userLogin.getPassword(),StandardCharsets.UTF_8).toString();
		if(userRepository.findByEmail(userLogin.getEmailId())==null)
		{
			log.error("User not found with email Id : "+userLogin.getEmailId());
			throw new UserNotFoundException("User not found with emailid: "+userLogin.getEmailId());
		}
		else if(userRepository.findByEmailIdAndPassword(userLogin.getEmailId(),encryptedPassword).isEmpty())
		{
			log.error("User has given invalid login credentials ");
			throw new InvalidLoginCredentialsException("Invalid login credentials");
		}
		else if(currentUser==null) {
			currentUser=userRepository.findByEmailIdAndPassword(userLogin.getEmailId(),encryptedPassword).get(0);
			log.info("Login successful");
			return new ResponseEntity<>(new UserDto(currentUser),HttpStatus.OK);
			}
		log.info("Login has failed as user is already logged in.");
		return new ResponseEntity<>("Login failed, user already logged in.",HttpStatus.BAD_REQUEST);
	}
	
	/**
	 * This method is to logout the user from the system
	 * It throws UserNotLoggedInException
	 * @returns Http Response Entity
	 */
	@Override
	public ResponseEntity<Object> logoutUser() throws UserNotLoggedInException
	{
		if(currentUser!=null) {
			currentUser=null;
			log.info("User has logged out successfully");
			return new ResponseEntity<>("User logged out successfully",HttpStatus.OK);
		}
		log.error("No user has logged in");
		throw new UserNotLoggedInException("No user logged in");
	}

	



}
