package com.onlinegrocerydeliverysystem.serviceimpl;

import com.onlinegrocerydeliverysystem.service.PaymentService;

public class PaymentServiceImpl implements PaymentService {

}
