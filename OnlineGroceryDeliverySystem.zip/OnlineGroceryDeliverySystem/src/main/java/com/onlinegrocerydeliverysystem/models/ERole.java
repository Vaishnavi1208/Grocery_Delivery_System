package com.onlinegrocerydeliverysystem.models;

public enum ERole {
	ROLE_USER,
    ROLE_ADMIN
}
