package com.onlinegrocerydeliverysystem.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


/**
 * **
 * This is an Entity class here Product is an Entity class 
 * @see Products
 * 
 *
 */
@Entity
@Table(name="Stocks")
public class Product {
	
	/**
	 * Id annotation is to show primary key for 
	 * Product table 
	 */
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="p_id")
	private Long  productId;
	
	@Column(name="p_code")
	private String productCode;
	
	@Column(name="p_name")
	private String  productName;
	
	@Column(name="p_price")
	private int  productPrice;
	
	@Column(name="p_quantity")
	private int  productQuantity;
	
	@Column(name="p_category")
	private String  productCategory;
	
	/**
	 * @return the productId
	 */
	public Long getProductId() {
		return productId;
	}

	/**
	 * @param productId the productId to set
	 */
	public void setProductId(Long productId) {
		this.productId = productId;
	}

	/**
	 * @return the productCode
	 */
	public String getProductCode() {
		return productCode;
	}

	/**
	 * @param productCode the productCode to set
	 */
	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}

	/**
	 * @return the productName
	 */
	public String getProductName() {
		return productName;
	}

	/**
	 * @param productName the productName to set
	 */
	public void setProductName(String productName) {
		this.productName = productName;
	}

	/**
	 * @return the productPrice
	 */
	public int getProductPrice() {
		return productPrice;
	}

	/**
	 * @param productPrice the productPrice to set
	 */
	public void setProductPrice(int productPrice) {
		this.productPrice = productPrice;
	}
	
	/**
	 * @return the productQuantity
	 */
	public int getProductQuantity() {
		return productQuantity;
	}

	/**
	 * @param productQuantity the productQuantity to set
	 */
	public void setProductQuantity(int productQuantity) {
		this.productQuantity = productQuantity;
	}

	/**
	 * @return the productCategory
	 */
	public String getProductCategory() {
		return productCategory;
	}

	/**
	 * @param productCategory the productCategory to set
	 */
	public void setProductCategory(String productCategory) {
		this.productCategory = productCategory;
	}
	

	public Product() {
		super();
	}

	/**
	 * @param productCode
	 * @param productName
	 * @param productPrice
	 * @param productQuantity
	 * @param productCategory
	 */
	public Product(String productCode, String productName, int productPrice, int productQuantity,
			String productCategory) {
		this.productCode = productCode;
		this.productName = productName;
		this.productPrice = productPrice;
		this.productQuantity = productQuantity;
		this.productCategory = productCategory;
	}

	@Override
	public String toString() {
		return "Product [productId=" + productId + ", productCode=" + productCode + ", productName=" + productName+ 
				", productPrice=" + productPrice + ", productQuantity="+ productQuantity + ", productCategory=" + productCategory + "]";
	}
	
	
	
}
