package com.onlinegrocerydeliverysystem.service;

public interface PaymentService {

}
